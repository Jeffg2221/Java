public class Profile{
    public static void main(String[] args){
        System.out.println(" My name is Jeff Gomez");
        System.out.println(" I am 34 years old");
        System.out.println(" My hometown is Riverview,Fl");
    }
}